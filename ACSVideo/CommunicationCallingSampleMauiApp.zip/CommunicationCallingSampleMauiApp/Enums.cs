namespace CommunicationCallingSampleMauiApp;

public enum CallType
{
    TeamsCall,//
    GroupCall,
    OneToN,
    RoomsCall
}

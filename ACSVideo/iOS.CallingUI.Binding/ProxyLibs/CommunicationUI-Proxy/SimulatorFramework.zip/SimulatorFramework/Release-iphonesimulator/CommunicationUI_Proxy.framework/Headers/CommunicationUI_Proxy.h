//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//  Licensed under the MIT License.
//
#import <Foundation/Foundation.h>

//! Project version number for CommunicationUI_Proxy.
FOUNDATION_EXPORT double CommunicationUI_ProxyVersionNumber;

//! Project version string for CommunicationUI_Proxy.
FOUNDATION_EXPORT const unsigned char CommunicationUI_ProxyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CommunicationUI_Proxy/PublicHeader.h>


